<!-- Back To Top Button -->
<div id="backtotop"><a href="#"></a></div>
<!-- Scripts
================================================== -->
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/jquery-2.2.0.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/chosen.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/magnific-popup.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/owl.carousel.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/rangeSlider.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/sticky-kit.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/slick.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/masonry.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/mmenu.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/tooltips.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/custom.js"></script>

<!-- Maps -->
<script type="text/javascript" src="https://maps.google.com/maps/api/js?key=AIzaSyDmyasSBWi-tlcG7yXyiAR3cUlBT0vylgQ&sensor=false&language=en"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/infobox.min.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/markerclusterer.js"></script>
<script type="text/javascript" src="<?php echo e(url('frontend/'), false); ?>/scripts/maps.js"></script>


<?php echo $__env->yieldContent('js_after'); ?>
