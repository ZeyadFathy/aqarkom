<!DOCTYPE html>
<html dir="rtl" lang="ar">

<head>
    <meta charset="utf-8">
</head>

<body>

    <h2>
        Welcome to AQARITO,
    </h2>
    <p> This is Osama, the co-founders of AQARITO. I am reaching out to you personally to welcome you to our app.
        It is very important for me to have a close relationship with our customers. So, if you have a questions or concerns, please do not hesitate to contact us at any time.

        Also, I would like to offer you a simple gift is to add an unlimited number of ads for a month from the date of your registration.

        Happy Real Estate!
    </p>
    <h3>Osama </h3>
    <h3> AQARITO Co-founder</h3>
    <h2>
        مرحبا بك في عقاريتو,
    </h2>
    <p>
        انا أسامة، أحد المؤسسين المشاركين لتطبيق عقاريتو. أتواصل معك شخصيًا لأرحب بك في تطبيقنا.
        من المهم جدًا بالنسبة لي أن أقيم علاقة وثيقة مع عملائنا. لذا إذا كانت لديك أسئلة أو استفسارات، يرجى عدم التردد في الاتصال بنا في أي وقت.

        أيضًا، أود أن أقدم لك هدية بسيطة وهي إضافة عدد غير محدود من الإعلانات لمدة شهر من تاريخ تسجيلك.

    </p>
</body>

</html>