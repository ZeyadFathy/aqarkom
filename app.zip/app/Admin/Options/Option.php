<?php

namespace App\Admin\Options;

use Illuminate\Database\Eloquent\Model;

class Option extends Model
{
	protected $table = 'options';
}
